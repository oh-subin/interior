package com.DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

import com.DTO.cartDTO;

public class cartDAO {

	Connection conn = null;
	PreparedStatement psmt = null;
	ResultSet rs = null;

	int cnt = 0;

	// DB����
	public void getConn() {

		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			String url = "jdbc:oracle:thin:@127.0.0.1:1521:xe";
			String dbid = "hr";
			String dbpw = "hr";
			conn = DriverManager.getConnection(url, dbid, dbpw);
			// db���� ����x
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// DB���� ����
	public void close() {

		try {

			if (rs != null) {
				rs.close();

			}
			if (psmt != null) {
				psmt.close();
			}
			if (conn != null) {
				conn.close();
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ���� īƮ�� ��ǰ �ֱ�
	public int cart_insert(String email, String cart_product) {
		getConn();
		
		try {
			// DB���� ���
			String sql = "insert into cart values(CART_SEQ.nextval, ?, ?)";

			psmt = conn.prepareStatement(sql);

			psmt.setString(1, email);
			psmt.setString(2, cart_product);

			cnt = psmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cnt;
	}
	
	// ��ü ��ٱ��� �����ִ� ���
	public ArrayList<cartDTO> showCart() {
		
		cartDTO cart = null;
		ArrayList<cartDTO> cartList = new ArrayList<>();
				
		try {
			// DB ����	
			getConn(); 
			
			// ------------------- DB�� SQL ���ɹ� �غ�
			String sql = "select * from cart";
			psmt = conn.prepareStatement(sql);
			
			rs = psmt.executeQuery();
			
			
			while(rs.next()) {
				
				//��ü ��ٱ��� �����͸� ���
				int cart_num = rs.getInt(1);
				String email = rs.getString(2);
				String product = rs.getString(3);
				
				// cartDTO ��ü�� 1���� DB���� ���� ��, ArrayList�� cartList�� ����
				cart = new cartDTO(cart_num, email, product);
				cartList.add(cart);
			}
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			close();
		}
		return cartList;	
	}
//	public int delete_Cart(String email) {
//		try {
//			
//			dao.getConn();
//			// ------------------------ DB����
//			
//			String sql = "delete from cart where email=?";
//			pst = Connect.conn.prepareStatement(sql);
//			
//			pst.setString(1, email);
//			
//			cnt = pst.executeUpdate();
//			
//		} catch {
//			
//		}
//		return cnt;
//	}
}
