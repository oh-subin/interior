package com.DTO;

public class cartDTO {
	private int cart_num;
	private String email;
	private String cart_product;

	public cartDTO(int cart_num, String email, String cart_product) {
		super();
		this.cart_num = cart_num;
		this.email = email;
		this.cart_product = cart_product;
	}

	public int getCart_num() {
		return cart_num;
	}

	public void setCart_num(int cart_num) {
		this.cart_num = cart_num;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCart_product() {
		return cart_product;
	}

	public void setCart_product(String cart_product) {
		this.cart_product = cart_product;
	}

}
